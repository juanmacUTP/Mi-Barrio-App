import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:mi_barrio_app/controller/store_controller.dart';
import 'package:mi_barrio_app/view/home_view.dart';


Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp().then((value){
    StoreDAO.addStoresFromServer().then((value) => runApp(const HomeView()));
  });

}
