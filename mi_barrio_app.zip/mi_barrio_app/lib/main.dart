import 'package:flutter/material.dart';
import 'package:mi_barrio_app/controller/store_controller.dart';
import 'package:mi_barrio_app/view/home_view.dart';


void main() {
  WidgetsFlutterBinding.ensureInitialized();
  StoreDAO.addStoresFromServer().then((value) => runApp(HomeView()));
}
