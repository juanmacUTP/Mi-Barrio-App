import 'package:flutter/material.dart';
import 'package:mi_barrio_app/view/stores_view.dart';
import 'package:mi_barrio_app/view/suggestions_view.dart';
import 'form_view.dart';


class HomeView extends StatelessWidget {
  HomeView({Key? key}) : super(key: key);

  final List<String> images = [
    "assets/client_register.png",
    "assets/generate.png",
    "assets/stores_list.png",
    "assets/suggests.png"
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        home: Scaffold(
            appBar: AppBar(
              title: const Text("Mi Barrio App"),
              centerTitle: true,
              backgroundColor: Colors.blueAccent,
              actions: <Widget>[
                PopupMenuButton<int>(
                  onSelected: (item) => handleTap(item),
                  itemBuilder: (context) => [
                    const PopupMenuItem<int>(value: 0, child: Text('Login')),
                    const PopupMenuItem<int>(value: 1, child: Text('Cerrar sesión')),
                  ],
                ),
              ],
            ),
            body: Container(
                padding: const EdgeInsets.all(20.0),
                child: GridView.builder(
                    itemCount: images.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 4.0,
                      mainAxisSpacing: 10.0
                    ),
                    itemBuilder: (context, int index) => buildCell(context, index),
                ))
        ),
    );
  }
  Widget buildCell(BuildContext context, int index){
     return GestureDetector(
      onTap: (){
        _navigateTo(context, index);
      },
      child: Image.asset(
        images[index],
        fit: BoxFit.cover,
        width: 90.0,
        height: 90.0,
      ),
    );
  }

  _navigateTo(BuildContext context, int index){
    if(index == 0){
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const FormPage())
      );
    }else if(index == 1) {
      /*var t2 = Store(idstore: "1106", namestore: "Gato", adresstore: "Gato", latitude: 2, longitude: 1,
          cellphonestore: "132156", email: "gato@gato.com", webpage: "www.gato.com",
          typestore: StoresType.ferreteria, logo: "xxx");
      DbManager.db.insertNewStore(t2);
      DbManager.db.storesList("select * FROM Store").then((value) => print(value));
      Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => StoresListView())
      );*/
    }else if(index == 2) {
      Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const StoresListView())
      );
    }else if(index == 3) {
      Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const SuggestionsForm())
      );
    }
  }
  void handleTap(int item) {
    switch (item) {
      case 0:
        /*Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => )
        );*/
        break;
      case 1:
        break;
    }
  }

}
