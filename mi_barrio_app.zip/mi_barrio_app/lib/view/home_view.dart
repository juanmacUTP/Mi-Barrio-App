import 'package:flutter/material.dart';
import 'package:mi_barrio_app/controller/db_connection.dart';
import 'package:mi_barrio_app/model/stores.dart';
import 'package:mi_barrio_app/view/stores_view.dart';
import 'form_view.dart';


class HomeView extends StatelessWidget {
  HomeView({Key? key}) : super(key: key);

  List<String> images = [
    "assets/client_register.png",
    "assets/generate.png",
    "assets/stores_list.png",
    "assets/suggests.png"
  ];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
        home: Scaffold(
            appBar: AppBar(
              title: const Text("Mi barrio App"),
              backgroundColor: Colors.blueAccent,
            ),
            body: Container(
                padding: const EdgeInsets.all(12.0),
                child: GridView.builder(
                    itemCount: images.length,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      crossAxisSpacing: 4.0,
                    ),
                    itemBuilder: (context, int index) => buildCell(context, index),
                ))
        ),
    );
  }
  Widget buildCell(BuildContext context, int index){
     return GestureDetector(
      onTap: (){
        _navigateTo(context, index);
      },
      child: Image.asset(
        images[index],
        fit: BoxFit.cover,
        width: 110.0,
        height: 110.0,
      ),
    );
  }

  _navigateTo(BuildContext context, int index){
    if(index == 0){
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const FormPage())
      );
    }else if(index == 1) {
      var t2 = Store(idstore: "1106", namestore: "Gato", adresstore: "Gato", latitude: 2, longitude: 1,
          cellphonestore: "132156", email: "gato@gato.com", webpage: "www.gato.com",
          typestore: StoresType.ferreteria, logo: "xxx");
      DbManager.db.insertNewStore(t2);
      DbManager.db.storesList("select * FROM Store").then((value) => print(value));
      /*Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => StoresListView())
      );*/
    }else if(index == 2) {
      Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const StoresListView())
      );
    }else if(index == 3) {
      /*Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => StoresListView())
      );*/
    }
  }

}
