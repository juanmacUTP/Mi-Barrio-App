class Product{
  late int id;
  late String name, unity;
  late double price;

  Product(this.id, this.name, this.unity, this.price);

  //data = id;name;unity;price
  Product.fromString(String data){
    List<String> listpr = data.split(";");
    id = int.parse(listpr[0]);
    name = listpr[1];
    unity = listpr[2];
    price = double.parse(listpr[3]);
  }


}